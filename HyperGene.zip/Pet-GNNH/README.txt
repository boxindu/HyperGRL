-- This is a Python implementation for HyperGene model
-- Basic requirements: Python >= 3.6, pytorch >= 1.6.0, dgl >= 0.5

-- To run the code,
    python main.py
    will show a quick demo.